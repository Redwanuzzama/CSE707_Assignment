#!/bin/bash
VAR="Hello world"
echo $VAR
VAR2=$(ls -lh)
echo $VAR2

for VAR3 in *.fastq
do
     echo $VAR3
done
